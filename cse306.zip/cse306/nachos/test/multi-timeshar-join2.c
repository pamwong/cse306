#include "syscall.h"


int main()
{
  Write("Multiprog-timeshare-join 2\n",27,ConsoleOutput);
  Exit('a');
}
