#include "syscall.h"

int main()
{
  Write("Multiprogramming 2\n",19,ConsoleOutput);
  Exit(0);
}
