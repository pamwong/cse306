#include "syscall.h"

int main()

{
  SpaceId s2;
  int i;

  Write("Bigger.\n",8,1);
  for (i=0; i < 16; i++);
  Exit(0);
}
