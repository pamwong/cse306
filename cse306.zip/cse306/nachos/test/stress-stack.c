

void recur()
{
  int x= 4;

  Write("success\n", 8, 1);
  recur();
}

int main()
{
  recur();
}
