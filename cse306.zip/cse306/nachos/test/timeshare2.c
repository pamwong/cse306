
#include "syscall.h"

int main()
{
  int i,j;
  
  for(i=0;i<10;i++) {
	for(j=0; j < 100; j++);
    Write("Timesharing 2\n",14,ConsoleOutput);
  }
  
  Exit(0);
}
