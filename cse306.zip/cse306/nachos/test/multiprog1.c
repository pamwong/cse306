#include "syscall.h"

int main()
{
  Exec("multiprog2");
  Write("Multiprogramming 1\n",19,ConsoleOutput);
}
