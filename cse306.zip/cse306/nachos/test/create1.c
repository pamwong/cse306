/* Tests Create() system call */

#include "syscall.h"

int main()
{
  Create("create-test");
}

